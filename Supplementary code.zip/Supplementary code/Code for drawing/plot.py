from cProfile import label
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.pyplot import MultipleLocator
from collections import Counter  

path = './MAE.csv'
path_inceptionv2 = './MAE_inceptionv2.csv'
path_auto = './MAE_auto.csv'
path_group = './MAE_auto_group2_modify.csv'
path_mixgroup = './MAE_auto_mixgroup.csv'

data = pd.read_csv(path)
data2 = pd.read_csv(path_inceptionv2)
data3 = pd.read_csv(path_auto)
data4 = pd.read_csv(path_group)
data5 = pd.read_csv(path_mixgroup)

x = data['boneage']
# x2 = data2['boneage']
# x3 = data3['boneage']
x4 = data4['boneage']
x5 = data5['boneage']


y = data['MAE']
y2 = data2['MAE']
y3 = data3['MAE']
y4 = data4['MAE']
y5 = data5['MAE']

length = len(x)
length_group2 = len(x4)
length_mixgroup = len(x5)


# 选取训练数据集中age重复一定次数的图片 (只有重复一定次数才有统计价值)
single = []
def singlenumber(x, number):
    count = 0
    for i in x:
        if(i == number):
            count += 1
    if(count <= 6 and count >=1):
        single.append(number)

# 统计需要去掉的点的序号 这句话一定要放在取均值之前
for i in range(1,229):
    singlenumber(x, i)



# 计算年龄重复的图片的均值并返回新列表
def average_mae(x, y, size):

    total = y[0]
    count = 1
    changdu = 0
    
    for i in range(1, size):
        if(x[i - 1] == x[i]):
            continue
        else:
           changdu  += 1
    x_temp = [''] * changdu
    y_temp = [''] * changdu
    j = 0
    for i in range(1, size):
        if(x[i -1 ] == x[i]):
            
            total += y[i]
            count += 1
        else:
            # if(repeat > 1):
            x_temp[j] = x[i - 1]
            y_temp[j] = total / count
            total = y[i]
            count = 1
            j += 1

    return x_temp, y_temp

# 取MAE的均值
# x, y = average_mae(x, y, size=length)
x, y2 = average_mae(x, y2, size=length)
# x3, y3 = average_mae(x3, y3, size=length)
# x4, y4 = average_mae(x4, y4, size=length_group2)
x5, y5 = average_mae(x5, y5, size=length_mixgroup)

# 去重
# for i in range(1,220):
#     singlenumber(x, i)

for i in single:
    # y.remove(y[x.index(i)])
    y2.remove(y2[x.index(i)])
    # y3.remove(y3[x.index(i)])
    # y4.remove(y4[x4.index(i)])
    # y5.remove(y5[x5.index(i)])
    x.remove(i)
    # x2.remove(i)
    # x3.remove(i)
    # x4.remove(i)
    # x5.remove(i)
    
# 纵坐标 months -> days
y = [i * 30 for i in y]
y2 = [i * 30 for i in y2]
y3 = [i * 30 for i in y3]
y4 = [i * 30 for i in y4]
y5 = [i * 30 for i in y5]

# y5.remove(y5[x5.index(12)])
# x5.remove(12)

# y2[0] -= 100
# y2[1] -= 80
# y2[2] -= 80
# y2[3] -= 80
# y2[4] -= 80

# plt.scatter(x, y, s=5, c='b')
plt.scatter(x, y2, s=5, c='r')
# plt.scatter(x, y3, s=5, c='y')
# plt.scatter(x4, y4, s=5, c='g')
# plt.scatter(x5, y5, s=5, c='g')
# plt.plot(x, y, color = '#4169E1', alpha=0.8, label='LCFF')

# plt.scatter(x, y * 30, s=5, c='b')
# plt.scatter(x, y2 * 30, s=5, c='r')
# plt.scatter(x, y3 * 30, s=5, c='r')
# plt.plot(x, y * 30, color = '#4169E1', alpha=0.8, label='LCFF')

plt.xlabel("Age(months)")
plt.ylabel("Error(days)")
# plt.xlim(-5,210)
plt.xlim(0,240)
# plt.xlim(80,140)
plt.ylim(50,300)
# plt.ylim(-5,1300)

plt.savefig('./test.pdf')
plt.show()


