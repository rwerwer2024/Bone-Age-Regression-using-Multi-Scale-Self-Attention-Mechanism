plot.py draws the code of error scatter plot
plot_dha.py and plot_rsna.py draw the code of data set column frequency graph
kmeans.py uses t-sne to draw the two-dimensional visualization result of network prediction value

Note: Please change the csv files used in all codes to local absolute paths; some csv files are intermediate results in the process of code debugging and have no meaning. If it prompts missing files, please comment them out.