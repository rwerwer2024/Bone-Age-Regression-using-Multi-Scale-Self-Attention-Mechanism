from cProfile import label
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.pyplot import MultipleLocator
from collections import Counter  

path = './MAE.csv'

data = pd.read_csv(path)

x = data['boneage'] / 12

xTicks = np.linspace(1,20,20)
plt.xticks(xTicks)

# yTicks = np.linspace(0, 0.18, 0.02)

yTicks = [0.00, 0.02, 0.04, 0.06, 0.08, 0.10, 0.12, 0.14, 0.16]
# plt.yticks(yTicks)


plt.hist(x, weights=np.zeros_like(x) + 1/ len(x), bins=20, rwidth=0.8, color='#FF7F50')
# plt.hist(x, bins=20, rwidth=0.8)

# plt.title("data analyze")
plt.xlabel("Chronological Bone Age")
plt.ylabel("Frequency")


for y in yTicks:
    plt.axhline(y = y, ls=":", c = '#C0C0C0')



plt.ylim(0, 0.17)
plt.xlim(0, 19)
plt.show()

plt.savefig('./rsna_frequency.pdf')

# print(1)