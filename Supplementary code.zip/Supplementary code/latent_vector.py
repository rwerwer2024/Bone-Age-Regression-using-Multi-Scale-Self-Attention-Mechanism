
EPOCHS = 300 # should be at least 50, 1 is for testing purposes
GRAD_NORM_CLIP = 0.1
LEARNING_RATE = 1e-4
# GENDER_SENSITIVE = True
GENDER_SENSITIVE = False

# trained model path to be loaded
LOAD_MIXED = None
LOAD_MALE = None
LOAD_FEMALE = None


# In[10]:

import csv
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
import collections
import datetime
import math
import numpy as np 
import tqdm
import pandas as pd
import copy

import torch
import torch.optim as optim
import torch.nn as nn

# from model import Res_Vit_B16 as Model,BasicBlock
# from model2 import Res_Vit_B16 as Model,BasicBlock
# from model_LayerMSA_gender import Res_Vit_B16_gender_512 as Model,BasicBlock
from model_LayerMSA_gender import Res_Vit_B16_gender_512_new as Model,BasicBlock

# from radam_optimizer import RAdam

# from dataset import load_image, generate_dataset
from dataset_gender import load_image, generate_dataset

if not GENDER_SENSITIVE:
    # prepare full dataset
    full_mixed_dataset, mixed_train_dataset, mixed_val_dataset, mixed_train_loader, mixed_val_loader = generate_dataset(None)
    print('Dataset length: ', len(full_mixed_dataset))
    print('Full ds item: ', full_mixed_dataset[0]['images'].shape, full_mixed_dataset[0]['labels'].shape)

else:
    # prepare male dataset
    full_male_dataset, male_train_dataset, male_val_dataset, male_train_loader, male_val_loader = generate_dataset(True)
    print('Male dataset length: ', len(full_male_dataset))
    print('Male ds item: ', full_male_dataset[0]['images'].shape, full_male_dataset[0]['labels'].shape)

    # prepare female dataset
    full_female_dataset, female_train_dataset, female_val_dataset, female_train_loader, female_val_loader = generate_dataset(False)
    print('Female dataset length: ', len(full_female_dataset))
    print('Female ds item: ', full_female_dataset[0]['images'].shape, full_female_dataset[0]['labels'].shape)


# 此处为第一步训练好的效果最好的模型文件
weight_path = 'D:\\work\\k_means\\LayerMSA_newmodel_512_gender_1000-1024-1_4.733.pt'

# 复现要求：1.去掉Layernorm；2.打开model.eval()

# weight_path = 'D:\\work\\k_means\\DHA_trans_f5.pt'
# weight_path = 'D:\\work\\k_means\\LayerMSA_newmodel_512_gender_1000-256-1_4.835.pt'
# weight_path = 'D:\\work\\k_means\\LayerMSA_newmodel_512_gender_1000-256-1.pt'
# weight_path = 'D:\\work\\k_means\\2222_1000-256-1_group3_3.812.pt'
# weight_path = 'D:\\work\\k_means\\2222_1000-256-1_group0_1.623.pt'
# weight_path = 'D:\\work\\k_means\\Inception_FC4_new.pt'

def generate_model():

    print('Generating model')
    checkpoint = torch.load(weight_path)
    model = checkpoint['model']

    state_dic = model.state_dict()
    # copymodel = model
    # del_keys = ['add2.weight','add2.bias']
    # for key in del_keys:
    #     del state_dic[key]

    copymodel = Model(block=BasicBlock,layers=[3,4,6,3],in_channels=3,depth=0)
    
    copymodel.load_state_dict(state_dict=state_dic,strict=False)
    # model = Model(block=BasicBlock,layers=[3,4,6,3],in_channels=3,depth=0)
    copymodel.cuda()
    # print(model)
    
    # pre_dict = torch.load(weight_path)
    # del_keys = ['fc.weight','fc.bias']
    # for key in del_keys:
    #     del pre_dict[key]
    # model.load_state_dict(pre_dict,strict=True)

    # optimizer = RAdam(model.parameters(), lr=LEARNING_RATE)
    optimizer = optim.Adam(model.parameters(),lr=LEARNING_RATE)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, patience=10, verbose=True)
    
    return copymodel, optimizer, scheduler

def load_model(path):
    print('Loading model from ', path)
    checkpoint = torch.load(path)
    print('Loaded ' + path + ' on epoch', checkpoint['epoch'], 'train loss:', checkpoint['train_loss'], 'and val loss: ', checkpoint['val_loss'])
    return checkpoint['model'], checkpoint['optimizer'], checkpoint['scheduler']


if not GENDER_SENSITIVE:
    # full mixed (male/female) model
    if LOAD_MIXED is None:
        mixed_model, mixed_optimizer, mixed_scheduler = generate_model()
    else:
        mixed_model, mixed_optimizer, mixed_scheduler = load_model(LOAD_MIXED)
    # print(mixed_model)
    
else:
    # male model
    if LOAD_MALE is None:
        male_model, male_optimizer, male_scheduler = generate_model()
    else:
        male_model, male_optimizer, male_scheduler = load_model(LOAD_MALE)
        
    # female model
    if LOAD_FEMALE is None:
        female_model, female_optimizer, female_scheduler = generate_model()
    else:
        female_model, female_optimizer, female_scheduler = load_model(LOAD_FEMALE)

def save_model(experiment_name, model, optimizer, scheduler, epoch, train_loss, val_loss):
    checkpoint = {
        "model": model,
        "optimizer": optimizer,
        "scheduler": scheduler,
        "epoch": epoch,
        "train_loss": train_loss,
        "val_loss": val_loss
    }

    print('Model ' + experiment_name + ' saved.')


def predict(experiment_name, model, optimizer, scheduler, train_loader, val_loader, epochs=EPOCHS):

    # 开了这个,batchnorm层对batchsize大小不会有影响(好像又不是)；否则必须固定测试集的batchsize大小
    model.eval()

    loss_fn = nn.MSELoss()
    metrics = nn.L1Loss()   

    # csvFile = open("1024\\DHA_reading1\\DHAf5_test.csv","w",newline= '')
    csvFile = open("1024\\123.csv","w",newline= '')
    writer = csv.writer(csvFile)
    list1 = [i for i in range(1,1025)]
    writer.writerow(list1)

    # loader = train_loader
    loader = val_loader


    with torch.no_grad():
        for epoch_num in range(1):

            train_loss_hist = []

            epoch_loss = []

            L1_hist = []

            # print(len(val_loader))

            progress = tqdm.tqdm(total=len(loader), desc='Testing Status', position=0)
            for iter_num, data in enumerate(loader):
                i = iter_num
            # for iter_num, data in enumerate(val_loader):
                # optimizer.zero_grad()

                # preds = model(data['images'].cuda().float())
                preds = model(data['images'].cuda().float(),data['gender'].cuda().float())



                list_preds = torch.squeeze(preds)
                list_preds = list_preds.tolist()

                # writer.writerow(list_preds)
                # progress.update(1)
                # continue

                loss = loss_fn(preds, data['labels'].cuda().float())
                L1 = metrics(preds,data['labels'].cuda().float())

                # if i == 1:
                #     print(data['labels'])
                #     print(L1)
                # loss = loss.mean()

                if bool(loss == 0):
                    continue

                loss = float(loss)
                
                train_loss_hist.append(loss)
                L1_hist.append(L1.item())

                epoch_loss.append(loss)
                
                progress.set_description(
                    desc='Test - Ep: {} | It: {} | Ls: {:1.3f} | mLs: {:1.3f} | MAE: {:1.3f}'.format(
                        epoch_num, 
                        iter_num, 
                        loss, 
                        np.mean(train_loss_hist),
                        L1.item()
                        # math.sqrt(loss)
                    )
                )
                
                progress.update(1)
                
                del loss

            train_loss = np.mean(train_loss_hist)
            # train_mae = math.sqrt(train_loss)
            train_mae = np.mean(L1_hist)
            
            # writer.add_scalar('loss/train_loss_mean', train_loss, epoch_num)
            # writer.add_scalar('loss/train_mae', train_mae, epoch_num)
            
            print('Test - Ep: {} | Ls: {:1.3f} | MAE: {:1.3f}'.format(epoch_num, train_loss, train_mae))
            # print(L1_hist)
        
    return 


if not GENDER_SENSITIVE:
    print('\nTESTING MIXED MODEL')
    predict('mixed', mixed_model, mixed_optimizer, mixed_scheduler, mixed_train_loader, mixed_val_loader, EPOCHS)
else:
    print('\nTESTING MALE MODEL')
    predict('male', male_model, male_optimizer, male_scheduler, male_train_loader, male_val_loader, EPOCHS)
    print('\nTESTING FEMALE MODEL')
    predict('female', female_model, female_optimizer, female_scheduler, female_train_loader, female_val_loader, EPOCHS)
    
    