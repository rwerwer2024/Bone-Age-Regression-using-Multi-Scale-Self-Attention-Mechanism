import time
import numpy as np
import matplotlib.pyplot as plt

from sklearn import datasets
from sklearn.cluster import KMeans
from sklearn.metrics.pairwise import pairwise_distances_argmin
# from sklearn.datasets.samples_generator import make_blobs
from sklearn.datasets import make_blobs
from sqlalchemy import true
from openTSNE import TSNE
import pandas as pd
import numpy as np
import csv
"""
    操作顺序：
    1.先用训练数据集的latent vector进行kmeans聚类,将结果写入一个csv文件;
    2.再用测试数据集的latent vector,按照1中的聚类中心,判断测试数据集中的每一张图片属于哪一类;再将结果写入一个csv文件
    说明:1步骤使用kmeans聚类的结果;2步骤是用1步骤的聚类中心来判断欧式距离,在进行类间的归属判断；

"""

n_clusters = 7
colors = ['#4EACC5', '#FF9C34', '#4E9A06','#FF0000','#9932CC','#000000','#0000CD']

# 原本的train.csv文件加了两列
csv_path = 'D:\\work\\k_means\\1024\\train2.csv'
# csv_path_test = 'D:\\work\\k_means\\1024\\test.csv'

# csv_path = 'D:\\work\\k_means\\1024\\DHA_reading1\\DHAf3_train.csv'
csv_path_test = 'D:\\work\\k_means\\1024\\test.csv'
# label_path = 'D:\\work\\k_means\\1024\\label2.csv'

X = pd.read_csv(csv_path)
X = X.values

X_test = pd.read_csv(csv_path_test)
X_test = X_test.values

k_means = KMeans(init='k-means++', n_clusters=n_clusters, n_init=10)
t0 = time.time()
k_means.fit(X)
t_batch = time.time() - t0
k_means_cluster_centers = np.sort(k_means.cluster_centers_, axis=0)
k_means_labels = pairwise_distances_argmin(X, k_means_cluster_centers)
k_means_labels_test = pairwise_distances_argmin(X_test,k_means_cluster_centers)

# 把分组的结果写入一个csv文件，之后把这一列复制到标签文件的最右边
# csvFile = open("1024\\DHA_reading1\\groups\\DHAf1_train_groups.csv","w",newline= '')
# csvFile = open("1024\\DHA_reading1\\RSNA_clusters_groups\\DHAf5_test_groups.csv","w",newline= '')
# csvFile = open("1024\\train_6groups.csv","w",newline= '')
csvFile = open("1024\\train_3groups.csv","w",newline= '')
writer = csv.writer(csvFile)

# 训练数据集写入
list1 = k_means_labels.tolist()
# 测试数据集写入
# list1 = k_means_labels_test.tolist()
for item in list1:
    a = []
    # item = list(item)
    a.append(item)
    writer.writerow(a)


row, _ = X.shape
X = np.append(X,k_means_cluster_centers,axis=0)
embedding = TSNE().fit(X)

fig = plt.figure(figsize=(8,4))

ax1 = fig.add_subplot(1,2,1)

for i in range(row):
    ax1.plot(embedding[i, 0], embedding[i, 1], '#4EACC5', marker='.')

ax1.set_title('Original Data')
# ax.set_xticks(())
# ax.set_yticks(())

ax2 = fig.add_subplot(1, 2, 2)

embedding_centers = embedding[row:]
embedding = embedding[:row]


for k, col in zip(range(n_clusters), colors):
    # k_means_labels里面每个位置的索引值如果等于k,my_members对应的位置就赋值为True
    my_members = k_means_labels == k		# my_members是布尔型的数组（用于筛选同类的点，用不同颜色表示）
    cluster_center = k_means_cluster_centers[k]
    # cluster_center = embedding_center[k]

    # 每次把索引为True的点画在图上
    ax2.plot(embedding[my_members, 0], embedding[my_members, 1], 'w',
            markerfacecolor=col, marker='.')	# 将同一类的点表示出来

    # ax.plot(cluster_center[0], cluster_center[1], 'o', markerfacecolor=col,
    #         markeredgecolor='k', marker='o')

    ax2.plot(embedding_centers[k][0], embedding_centers[k][1], markerfacecolor=col,
            markeredgecolor='k', marker='o')

ax2.set_title('KMeans')
# ax.savefig('./f10_1.pdf')
# ax.set_xticks(())
# ax.set_yticks(())

# plt.text(-3.5, 1.8, 'train time: %.2fs\ninertia: %f' % (t_batch, k_means.inertia_))
# print('training time:%.2f' % (t_batch))

# plt.savefig('./f10_1.pdf')

# 只保存第二个子图
bbox = ax2.get_tightbbox(fig.canvas.get_renderer()).expanded(1.05, 1.05)
extent = bbox.transformed(fig.dpi_scale_trans.inverted())
fig.savefig('./f10_5.pdf', bbox_inches=extent)

# plt.show()

